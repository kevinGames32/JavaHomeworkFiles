the assignment has 2 parts.
part1: 100% credit, print all of the possible combinations
part2: extra credit #2, print combinations excluding leading zeroes.

assigment asks the user for 1 of 2 options, option 1 is the base assignment and option 2 the 2nd extra credit option